package com.example.budgetapp.ProcessingActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.budgetapp.R;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class ImportActivity extends AppCompatActivity {

    TextView mFileTextView;
    Button mFileUploadButton;

    private FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import);

        initializeFields();

//        mFileUploadButton.setOnClickListener();

        //CollectionReference m = db.collection("users");
//        m.add(new Object()).hashCode/
    }

    private void initializeFields() {
        mFileTextView = findViewById(R.id.fileTextView);
        mFileUploadButton = findViewById(R.id.fileUploadButton);
    }
}
