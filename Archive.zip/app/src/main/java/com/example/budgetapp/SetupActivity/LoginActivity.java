package com.example.budgetapp.SetupActivity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.budgetapp.ProcessingActivity.ImportActivity;
import com.example.budgetapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import static java.util.Objects.isNull;

public class LoginActivity extends AppCompatActivity {

    EditText mEmailUser, mPasswordUser;
    Button mLoginButton, mSignupButton;
    ProgressBar mProgressBar;
    FirebaseAuth mFirebaseAuth;

    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mEmailUser = findViewById(R.id.edittextEmail);
        mPasswordUser = findViewById(R.id.registerPassword);
        mProgressBar = findViewById(R.id.progressBar);
        mFirebaseAuth = FirebaseAuth.getInstance();
        mLoginButton = findViewById(R.id.loginButton);
        mSignupButton = findViewById(R.id.signupButton);

        db = FirebaseFirestore.getInstance();

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = mEmailUser.getText().toString().trim();
                String password = mPasswordUser.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    mEmailUser.setError("Email is Required.");
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    mPasswordUser.setError("Password is Required.");
                    return;
                }

                if (password.length() < 6) {
                    mPasswordUser.setError("Password Must be >= 6 Characters");
                    return;
                }

                mProgressBar.setVisibility(View.VISIBLE);

                // authenticate the user

                mFirebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Toast.makeText(LoginActivity.this, "Logged in Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), ImportActivity.class));
                        } else {
                            Toast.makeText(LoginActivity.this, "Error ! " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            mProgressBar.setVisibility(View.GONE);
                        }

                    }
                });

            }
        });


        mSignupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class));
            }
        });
    }
}
